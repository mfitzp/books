import os
basedir = os.path.dirname(__file__)

# then ...
icon_path = os.path.join(basedir, "icon.svg")
